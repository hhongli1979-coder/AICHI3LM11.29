const Gifs = {
  lineAnimation: require('../../assets/gif/line.gif'),
  darkLineAnimationn: require('../../assets/gif/darkLine.gif'),
  ActiveRideGo: require('../../assets/gif/activeRideGo.gif'),
  success: require('../../assets/gif/success.gif')
}
export default Gifs


export const URL = 'your_api_url_here';

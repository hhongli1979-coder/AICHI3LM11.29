export interface IncentiveInterface {
    incentiveDataList?: IncentiveListInterface;
    success?: boolean;
    loading?: boolean;
    statusCode?: number;
}

export interface IncentiveListInterface {

}

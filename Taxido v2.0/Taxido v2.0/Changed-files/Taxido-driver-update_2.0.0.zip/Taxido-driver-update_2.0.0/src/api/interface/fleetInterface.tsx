export interface FleetVehicleInterface {
    fleetVehicle?: FleetVehicleListInterface[]
    fleetDriver?: FleetDriverListInterface[]
}

export interface FleetVehicleListInterface {

}

export interface FleetDriverListInterface {

}
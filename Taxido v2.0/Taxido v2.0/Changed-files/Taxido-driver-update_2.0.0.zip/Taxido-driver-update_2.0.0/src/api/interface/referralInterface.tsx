export interface ReferralInterface {
    success?: boolean;
    referralList?: any;
}

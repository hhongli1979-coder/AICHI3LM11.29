export const fleetVehicle = 'fleet/vehicleInfo'
export const fleetVehiclelist = 'fleet/vehicleInfo'
export const fleetDriverlist = 'driver'
export const fleetDriverDelete = 'fleet/driver'
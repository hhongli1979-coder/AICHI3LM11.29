export const referralBonus = 'referralBonus'

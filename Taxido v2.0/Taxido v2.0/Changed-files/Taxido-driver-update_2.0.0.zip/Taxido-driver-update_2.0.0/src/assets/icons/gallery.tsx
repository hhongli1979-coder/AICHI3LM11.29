import * as React from "react"
import { SVGProps } from "react"
import Svg, { Path } from "react-native-svg"
import appColors from "../../theme/appColors"

const SvgComponent = (props: SVGProps<SVGSVGElement>) => (
  <Svg
    width={20}
    height={20}
    fill="none"
    {...props}
  >
    <Path
      fill={appColors.primary}
      d="m2.149 15.841-.017.017a5.156 5.156 0 0 1-.425-1.667c.058.609.217 1.159.442 1.65ZM7.499 8.65a1.983 1.983 0 1 0 0-3.966 1.983 1.983 0 0 0 0 3.966Z"
    />
    <Path
      fill={appColors.primary}
      d="M13.493 1.667H6.51c-3.034 0-4.842 1.808-4.842 4.842v6.983c0 .908.158 1.7.467 2.367.716 1.583 2.25 2.475 4.375 2.475h6.983c3.033 0 4.842-1.809 4.842-4.842V6.509c0-3.034-1.809-4.842-4.842-4.842Zm3.483 8.75c-.65-.558-1.7-.558-2.35 0l-3.466 2.975c-.65.558-1.7.558-2.35 0l-.284-.233c-.591-.517-1.533-.567-2.2-.117L3.21 15.134a4.444 4.444 0 0 1-.292-1.642V6.509c0-2.35 1.242-3.592 3.592-3.592h6.983c2.35 0 3.592 1.242 3.592 3.592v4l-.109-.092Z"
    />
  </Svg>
)
export default SvgComponent
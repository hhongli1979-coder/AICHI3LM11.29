export interface RenderItemsProps {
    categoryIndex: number;
    selectedCategory: string;
    categoryId: number;
    handleItemPress: any
    selectedService: string;
}
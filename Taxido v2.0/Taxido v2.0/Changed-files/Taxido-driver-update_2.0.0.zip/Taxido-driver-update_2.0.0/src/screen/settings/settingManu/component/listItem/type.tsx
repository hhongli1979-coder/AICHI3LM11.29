interface ListItemProps {
  icon?: any
  text?: string
  onPress?: () => void
  backgroundColor?: string
  color?: string,
  showNextIcon?: any,
  dot?: any
}
export default ListItemProps

import { StyleSheet } from "react-native";
import { windowHeight } from "@src/themes";

const styles = StyleSheet.create({
    image: {
        height: windowHeight(8),
        width: '80%'
    },
})

export default styles;
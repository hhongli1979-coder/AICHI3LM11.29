import { StyleSheet } from "react-native";

const style = StyleSheet.create({
    shreTripView: {
        alignItems: "center",
        justifyContent: "center",
    },
})

export default style;
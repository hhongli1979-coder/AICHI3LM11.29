import { StyleSheet } from "react-native";

const styles = StyleSheet.create({
    modalview: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
    },
});
export default styles;
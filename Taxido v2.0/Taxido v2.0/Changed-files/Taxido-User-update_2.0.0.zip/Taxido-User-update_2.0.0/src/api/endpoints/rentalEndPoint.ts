export const rentalVehicle = 'vehicleType/locations';
export const rental_vehicle = 'rental-vehicle';
export const rentalRideRequest = 'rental/rideRequest';
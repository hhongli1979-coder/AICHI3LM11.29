export const userSelf = "rider/self";
export const editProfile = "updateProfile";
export const changePassword = "updatePassword";
export const deleteAccount = "rider/deleteAccount";
export const country = "country";
export const phoneOrEmail = "rider/updatePhoneOrEmail";
export const verifyPhoneOrEmail = "rider/verifyPhoneOrEmail"
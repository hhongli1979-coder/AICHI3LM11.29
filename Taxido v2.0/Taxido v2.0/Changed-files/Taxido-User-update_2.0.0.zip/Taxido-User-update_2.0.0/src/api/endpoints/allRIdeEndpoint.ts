export const ride = "ride"
export const payment = "ride/payment"
export const invoice = "ride/invoice"
export const locationChange = "ride/location/charge"